<?php
	
	define('DB_HOST', 'localhost');
	define('DB_USER', 'id3368465_data');
	define('DB_PASSWORD', 'funnyboy')

?>